#include<iostream>
#include<math.h>
using namespace std;

int main(){

    double x, i, S = 0, n = 1;
    cin >> x >> i;
    while ( n <= i)
    {
        S +=1 + pow(-1, n ) * pow(x, (2 * n));
        n ++;
    }
    printf("%.2f\n", S);
    return 0;
    
}